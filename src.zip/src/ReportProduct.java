
public class ReportProduct{
	
	
	
	
	
}