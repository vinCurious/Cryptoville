import java.util.HashMap;
import java.util.Map;

public class Config{

	static final double incentive = 10;
	static final int numberOfMachines = 4;
	
	
	
}