public interface BuyerInterface{
	
	int getBuyerID();
	String getBuyerName();
	
	void setBuyerID(int buyerID);
	void setBuyerName(String buyerName);
		
}