public interface MachineInterface{
	
	Transaction emitTransaction();
	
}