public interface FarmerInterface {

	int getFarmerID();
	String getFarmerName();
	String getFarmerState();
	
	void setFarmerID(int farmerID);
	void setFarmerName(String farmerName);
	void setFarmerState(String farmerState);
}
