
public class Buyer implements BuyerInterface{
	
	int buyerID;
	String buyerName;
	
	@Override
	public int getBuyerID() {
		// TODO Auto-generated method stub
		return this.buyerID;
	}
	@Override
	public String getBuyerName() {
		// TODO Auto-generated method stub
		return this.buyerName;
	}
	@Override
	public void setBuyerID(int buyerID) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void setBuyerName(String buyerName) {
		// TODO Auto-generated method stub
		
	}
	
	
}