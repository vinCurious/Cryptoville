public abstract class AbstractRegisterMe{
	 
	static boolean registerFarmer(int farmerID, String farmerName, String stateName){
		return false;
		
	}
	static boolean registerBuyer(int buyerID, String buyerName){
		return false;
	}

}